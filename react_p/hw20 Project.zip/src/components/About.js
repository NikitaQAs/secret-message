function About() {
    return (
        <div >
            <div>About this app</div>
        </div>
    );
}

export default About;