function Error() {
    return (
        <div >
            <div>Error 404</div>
        </div>
    );
}

export default Error;